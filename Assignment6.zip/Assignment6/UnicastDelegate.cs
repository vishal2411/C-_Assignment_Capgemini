﻿using System;

namespace Assignment6
{
    // Delegate Declaration
    public delegate void ManagerDelegate();
        internal class UnicastDelegate
        {
            static void Main(string[] args)
            {
                Manager manager = new Manager();

                ManagerDelegate managerDelegate = new ManagerDelegate(manager.printManagertDetails);

                managerDelegate.Invoke();
            }
        }

        // Manager Class
        public class Manager
        {
            private int managerID;
            private string managerName;
            private double managerSalary;

            public Manager()
            {
                Console.Write("Enter the Manager Id: ");
                this.managerID = (Convert.ToInt32(Console.ReadLine()));

                Console.Write("Enter the Manager Name : ");
                this.managerName = Console.ReadLine();

                Console.Write("Enter the Manager Salary : ");
                this.managerSalary = Convert.ToDouble(Console.ReadLine());
            }

            public void printManagertDetails()
            {
                Console.WriteLine("\n----- Manager Details --------\n");

                Console.WriteLine("Manager Id : {0}", managerID);
                Console.WriteLine("Manager Name : {0}", managerName);
                Console.WriteLine("Manager Salary : {0}", managerSalary);
            }
        }
}
